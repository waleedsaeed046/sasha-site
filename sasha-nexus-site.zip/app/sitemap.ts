export default async function sitemap() {
  const base = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  const routes = ["", "/services", "/industries", "/work", "/about", "/careers", "/blog", "/contact"].map(p => ({
    url: base + p,
    lastModified: new Date()
  }));
  return routes;
}