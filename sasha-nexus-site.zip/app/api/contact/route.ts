import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { Resend } from "resend";

const schema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  company: z.string().optional().default(""),
  budget: z.string().optional().default(""),
  message: z.string().min(10)
});

export async function POST(req: NextRequest) {
  const formData = await req.formData();
  const data = Object.fromEntries(formData.entries());
  const parse = schema.safeParse(data);

  if (!parse.success) {
    return NextResponse.json({ ok: false, errors: parse.error.flatten() }, { status: 400 });
  }

  const { name, email, company, budget, message } = parse.data;

  // Send Email via Resend
  const resendKey = process.env.RESEND_API_KEY;
  const fromEmail = process.env.RESEND_FROM_EMAIL || "no-reply@example.com";
  const toEmail = process.env.RESEND_TO_EMAIL || "admin@example.com";

  if (resendKey) {
    try {
      const resend = new Resend(resendKey);
      await resend.emails.send({
        from: fromEmail,
        to: toEmail,
        subject: `New contact: ${name} (${email})`,
        html: `<p><strong>Name:</strong> ${name}</p>
               <p><strong>Email:</strong> ${email}</p>
               <p><strong>Company:</strong> ${company || "-"}</p>
               <p><strong>Budget:</strong> ${budget || "-"}</p>
               <p><strong>Message:</strong></p><p>${message.replace(/\n/g, "<br/>")}</p>`
      });
    } catch (e) {
      console.error("Resend error", e);
    }
  }

  // Optional: HubSpot CRM (create/update contact + note)
  const hubspotToken = process.env.HUBSPOT_ACCESS_TOKEN;
  if (hubspotToken) {
    try {
      const headers = {
        "Authorization": `Bearer ${hubspotToken}`,
        "Content-Type": "application/json"
      };

      // Create or update contact
      const contactRes = await fetch("https://api.hubapi.com/crm/v3/objects/contacts", {
        method: "POST",
        headers,
        body: JSON.stringify({
          properties: {
            email,
            firstname: name.split(" ")[0],
            lastname: name.split(" ").slice(1).join(" ") || "—",
            company,
            lifecyclestage: "lead",
            message: message.slice(0, 10000)
          }
        })
      });

      if (!contactRes.ok) {
        // If exists, try update by email
        await fetch(`https://api.hubapi.com/crm/v3/objects/contacts/${encodeURIComponent(email)}`, {
          method: "PATCH",
          headers,
          body: JSON.stringify({ properties: { company, message: message.slice(0, 10000) } })
        }).catch(() => {});
      }
    } catch (e) {
      console.error("HubSpot error", e);
    }
  }

  return NextResponse.redirect(new URL("/contact?sent=1", req.url));
}