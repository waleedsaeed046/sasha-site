
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata("Services");

export default function Page() {{
  return (
    <div className="container py-16">
      <h1 className="text-4xl font-bold">Services</h1>
      <p className="mt-3 text-neutral-600 dark:text-neutral-300">What we do, how we deliver, and typical engagement models.</p>
      <div className="mt-8 text-neutral-700 dark:text-neutral-300 space-y-4">
        <p>Replace this section with real content.</p>
      </div>
    </div>
  );
}}
