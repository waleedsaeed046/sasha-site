import fs from "fs";
import path from "path";
import matter from "gray-matter";
import Link from "next/link";
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata("Blog", "Insights, case studies, and engineering notes from the Sasha Nexus team.");

const POSTS_DIR = path.join(process.cwd(), "content", "blog");

export default async function Page() {
  const files = fs.readdirSync(POSTS_DIR).filter(f => f.endsWith(".md"));
  const posts = files.map(filename => {
    const slug = filename.replace(/\.md$/, "");
    const file = fs.readFileSync(path.join(POSTS_DIR, filename), "utf-8");
    const { data } = matter(file);
    return { slug, ...(data as any) };
  }).sort((a:any,b:any)=> new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="container py-16">
      <h1 className="text-4xl font-bold">Blog</h1>
      <div className="mt-8 grid md:grid-cols-2 gap-6">
        {posts.map((p:any) => (
          <Link key={p.slug} href={`/blog/${p.slug}`} className="rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 hover:shadow-lg">
            <div className="text-xs uppercase tracking-widest text-indigo-600 dark:text-indigo-400 font-semibold">{p.tag || "Article"}</div>
            <h3 className="mt-2 font-semibold text-xl">{p.title}</h3>
            <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-300">{p.excerpt}</p>
            <div className="mt-3 text-xs text-neutral-500">{new Date(p.date).toLocaleDateString()}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}