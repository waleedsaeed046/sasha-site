import fs from "fs";
import path from "path";
import matter from "gray-matter";
import { remark } from "remark";
import html from "remark-html";
import { pageMetadata } from "@/lib/seo";

const POSTS_DIR = path.join(process.cwd(), "content", "blog");

export async function generateStaticParams() {
  const files = fs.readdirSync(POSTS_DIR).filter(f => f.endsWith(".md"));
  return files.map(f => ({ slug: f.replace(/\.md$/, "") }));
}

export default async function Page({ params }:{ params: { slug: string } }) {
  const fullPath = path.join(POSTS_DIR, params.slug + ".md");
  const file = fs.readFileSync(fullPath, "utf-8");
  const { data, content } = matter(file);
  const processed = await remark().use(html).process(content);
  const htmlContent = processed.toString();

  return (
    <div className="container py-16 prose prose-neutral max-w-3xl dark:prose-invert">
      <h1 className="text-4xl font-bold mb-2">{(data as any).title}</h1>
      <div className="text-sm text-neutral-500 mb-8">{new Date((data as any).date).toLocaleDateString()}</div>
      <article dangerouslySetInnerHTML={{ __html: htmlContent }} />
    </div>
  );
}

export async function generateMetadata({ params }:{ params: { slug: string } }) {
  const fullPath = path.join(POSTS_DIR, params.slug + ".md");
  const file = fs.readFileSync(fullPath, "utf-8");
  const { data } = matter(file);
  return pageMetadata((data as any).title, (data as any).excerpt);
}