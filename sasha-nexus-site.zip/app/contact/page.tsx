import { pageMetadata } from "@/lib/seo";
import { Button } from "@/components/Button";
import { site } from "@/lib/site";

export const metadata = pageMetadata("Contact");

export default function Page() {
  return (
    <div className="container py-16">
      <h1 className="text-4xl font-bold">Tell us about your project</h1>
      <p className="mt-3 text-neutral-600 dark:text-neutral-300">Share a few details. We'll get back within one business day.</p>

      <div className="grid lg:grid-cols-2 gap-10 mt-8">
        <form className="rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 space-y-4" method="POST" action="/api/contact">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-neutral-600 dark:text-neutral-300">Full name</label>
              <input name="name" type="text" required placeholder="Jane Doe" className="mt-1 w-full px-4 py-2.5 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div>
              <label className="text-sm text-neutral-600 dark:text-neutral-300">Email</label>
              <input name="email" type="email" required placeholder="you@company.com" className="mt-1 w-full px-4 py-2.5 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-neutral-600 dark:text-neutral-300">Company</label>
              <input name="company" type="text" placeholder="Sasha Nexus" className="mt-1 w-full px-4 py-2.5 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div>
              <label className="text-sm text-neutral-600 dark:text-neutral-300">Budget</label>
              <select name="budget" className="mt-1 w-full px-4 py-2.5 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option>£5k–£15k</option>
                <option>£15k–£50k</option>
                <option>£50k–£150k</option>
                <option>£150k+ (enterprise)</option>
              </select>
            </div>
          </div>
          <div>
            <label className="text-sm text-neutral-600 dark:text-neutral-300">Project details</label>
            <textarea name="message" rows={5} required placeholder="What are you trying to build? Goals, timeline, tech stack…" className="mt-1 w-full px-4 py-2.5 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
          </div>
          <div className="flex items-center justify-between">
            <div className="text-sm text-neutral-500 dark:text-neutral-400">We’ll never share your info.</div>
            <Button type="submit">Send message</Button>
          </div>
        </form>

        <div className="rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6">
          <div className="space-y-4 text-sm">
            <p><strong>Email:</strong> <a href={`mailto:${site.email}`}>{site.email}</a></p>
            <p><strong>Phone:</strong> <a href={`tel:${site.phone}`}>{site.phone}</a></p>
            <p><strong>Address:</strong> {site.address}</p>
          </div>
        </div>
      </div>
    </div>
  );
}