import { ArrowRight, Lock, Cpu, Cloud, Globe, Rocket, Database, Shield, CheckCircle2 } from "lucide-react";
import { Section } from "@/components/Section";
import { Button } from "@/components/Button";
import { Stat } from "@/components/Stat";
import { site } from "@/lib/site";

const services = [
  { icon: <Cpu className="w-6 h-6" />, title: "AI & Machine Learning", points: ["LLM apps & RAG", "Computer vision", "MLOps pipelines"] },
  { icon: <Cloud className="w-6 h-6" />, title: "Cloud & DevOps", points: ["AWS / Azure / GCP", "Kubernetes & IaC", "Cost & reliability"] },
  { icon: <Globe className="w-6 h-6" />, title: "Web Engineering", points: ["Next.js / React", "Headless CMS", "Accessibility (WCAG)"] },
  { icon: <Rocket className="w-6 h-6" />, title: "Mobile Apps", points: ["iOS / Android", "React Native", "App Store deploy"] },
  { icon: <Database className="w-6 h-6" />, title: "Data & Analytics", points: ["Data lakes & ETL", "Dashboards & BI", "Real-time streams"] },
  { icon: <Shield className="w-6 h-6" />, title: "Cybersecurity", points: ["Security audits", "Zero‑trust", "Compliance (ISO)"] },
];

export default function Page() {
  return (
    <div id="home">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-[radial-gradient(60rem_60rem_at_50%_-10%,rgba(99,102,241,0.25),transparent)] dark:bg-[radial-gradient(60rem_60rem_at_50%_-10%,rgba(99,102,241,0.15),transparent)]" />
          <div className="absolute -top-32 right-[-30%] h-[38rem] w-[38rem] rounded-full bg-gradient-to-br from-indigo-600/25 via-violet-500/25 to-fuchsia-500/25 blur-3xl" />
        </div>
        <div className="container py-20 sm:py-28">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div>
              <span className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-indigo-700 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 rounded-full px-3 py-1">
                Building the next wave
              </span>
              <h1 className="mt-4 text-4xl sm:text-5xl/tight font-extrabold">
                Software, Cloud & AI consulting for ambitious teams
              </h1>
              <p className="mt-4 text-lg text-neutral-600 dark:text-neutral-300 max-w-xl">
                {site.description}
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button as="a" href="/contact" size="lg">Start a project <ArrowRight className="w-5 h-5" /></Button>
                <Button as="a" href="/services" variant="outline" size="lg">Explore services</Button>
              </div>
              <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-6">
                <Stat k="Projects delivered" v="50+" />
                <Stat k="Enterprise clients" v="20+" />
                <Stat k="Uptime SLAs" v=">99.9%" />
                <Stat k="Support" v="24/7" />
              </div>
            </div>

            <div>
              <div className="relative">
                <div className="absolute -inset-1 rounded-3xl bg-gradient-to-tr from-indigo-600/40 via-violet-500/40 to-fuchsia-500/40 blur-xl" />
                <div className="relative rounded-3xl border border-neutral-200/70 dark:border-neutral-800 bg-white/90 dark:bg-neutral-950/80 backdrop-blur p-6 shadow-2xl">
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { title: "Next.js + Edge", text: "SSR, ISR & CDN" },
                      { title: "Kubernetes", text: "Auto-scale & GitOps" },
                      { title: "LLM Apps", text: "RAG, tools & agents" },
                      { title: "Observability", text: "Tracing & SLOs" },
                      { title: "Security", text: "Zero‑trust & SAST" },
                      { title: "Data", text: "ETL, lakehouse & BI" },
                    ].map((c, i) => (
                      <div key={i} className="rounded-2xl border border-neutral-200 dark:border-neutral-800 p-4">
                        <div className="text-sm text-neutral-500 dark:text-neutral-400">{c.title}</div>
                        <div className="font-semibold mt-1">{c.text}</div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-5 flex items-center gap-3 text-sm text-neutral-500 dark:text-neutral-400">
                    <Lock className="w-4 h-4" /> Enterprise-grade security by default
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Logos */}
      <div className="py-10 border-t border-neutral-200/70 dark:border-neutral-800/70">
        <div className="container">
          <div className="text-xs uppercase tracking-widest text-neutral-500 dark:text-neutral-400 font-semibold mb-6">Trusted by teams like</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
            {Array.from({length:6}).map((_, i) => (
              <div key={i} className="h-12 rounded-xl border border-dashed border-neutral-300 dark:border-neutral-700 flex items-center justify-center text-neutral-400 text-xs">
                Your Logo
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Services */}
      <Section id="services" eyebrow="What we do" title="Full‑stack product teams on demand" subtitle="From idea to enterprise scale, we assemble cross‑functional squads to ship high‑impact software.">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <div key={s.title} className="group rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 hover:shadow-lg hover:border-neutral-300 dark:hover:border-neutral-700">
              <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300 flex items-center justify-center">{s.icon}</div>
              <h3 className="mt-4 font-semibold text-lg">{s.title}</h3>
              <ul className="mt-3 space-y-2 text-sm text-neutral-600 dark:text-neutral-300">
                {s.points.map((p) => (
                  <li key={p} className="flex gap-2"><CheckCircle2 className="w-4 h-4 mt-0.5 text-indigo-500" /> <span>{p}</span></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}