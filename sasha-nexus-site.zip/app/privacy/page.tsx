
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata("Privacy Policy");

export default function Page() {{
  return (
    <div className="container py-16">
      <h1 className="text-4xl font-bold">Privacy Policy</h1>
      <p className="mt-3 text-neutral-600 dark:text-neutral-300">Your privacy matters. This is a placeholder policy page.</p>
      <div className="mt-8 text-neutral-700 dark:text-neutral-300 space-y-4">
        <p>Replace this section with real content.</p>
      </div>
    </div>
  );
}}
