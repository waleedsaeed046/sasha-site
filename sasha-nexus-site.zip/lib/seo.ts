import type { Metadata } from "next";
import { site } from "@/lib/site";

export const defaultMetadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: {
    default: site.name,
    template: `%s · ${site.name}`,
  },
  description: site.description,
  openGraph: {
    type: "website",
    title: site.name,
    description: site.description,
    images: ["/og.jpg"]
  },
  twitter: {
    card: "summary_large_image",
    title: site.name,
    description: site.description,
    images: ["/og.jpg"]
  },
  alternates: {
    types: { "application/rss+xml": "/rss.xml" }
  }
};

export function pageMetadata(title: string, description?: string): Metadata {
  return {
    title,
    description: description || site.description
  }
}