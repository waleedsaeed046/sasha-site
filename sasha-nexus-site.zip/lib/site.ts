export const site = {
  name: "Sasha Nexus",
  tagline: "Software, Cloud & AI consulting for ambitious teams",
  description:
    "Sasha Nexus partners with startups and enterprises to design, build, and scale secure digital products — fast.",
  email: "info@sashanexus.com",
  phone: "+44 7378 200606",
  address: "Office 12300, 182–184 High Street North, East Ham, London, E6 2JA",
  x: "#",
  linkedin: "#",
  github: "#"
};