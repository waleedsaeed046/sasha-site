"use client";
import Link from "next/link";
import Image from "next/image";
import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/Button";

const nav = [
  { label: "Services", href: "/services" },
  { label: "Industries", href: "/industries" },
  { label: "Work", href: "/work" },
  { label: "About", href: "/about" },
  { label: "Careers", href: "/careers" },
  { label: "Blog", href: "/blog" },
  { label: "Contact", href: "/contact" }
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(true);

  useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.add("dark");
    else root.classList.remove("dark");
  }, [dark]);

  return (
    <header className="sticky top-0 z-50 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-neutral-950/50 border-b border-neutral-200/60 dark:border-neutral-800/60">
      <div className="container h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Image src="/logo.png" alt="Sasha Nexus" width={32} height={32} className="rounded-md" />
          <span className="font-semibold tracking-tight">Sasha Nexus</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          {nav.map((n) => (
            <Link key={n.href} href={n.href} className="text-sm font-medium text-neutral-700 hover:text-neutral-900 dark:text-neutral-300 dark:hover:text-white">
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setDark((d) => !d)}>{dark ? "Light" : "Dark"} mode</Button>
          <Button as="a" href="/contact" size="sm">Talk to us</Button>
        </div>

        <button className="md:hidden p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800" onClick={() => setOpen(true)}>
          <Menu className="w-6 h-6" />
        </button>
      </div>

      {open && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/40" onClick={() => setOpen(false)}>
          <div className="absolute right-0 top-0 h-full w-[82%] max-w-sm bg-white dark:bg-neutral-900 shadow-xl p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <Link href="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
                <Image src="/logo.png" alt="Sasha Nexus" width={28} height={28} className="rounded-md" />
                <span className="font-semibold">Sasha Nexus</span>
              </Link>
              <button className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800" onClick={() => setOpen(false)}>
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="mt-6 space-y-3">
              {nav.map((n) => (
                <Link key={n.href} href={n.href} onClick={() => setOpen(false)} className="block px-3 py-2 rounded-xl text-neutral-800 hover:bg-neutral-100 dark:text-neutral-100 dark:hover:bg-neutral-800">
                  {n.label}
                </Link>
              ))}
              <div className="pt-2 flex gap-2">
                <Button className="flex-1" onClick={() => setDark((d) => !d)} variant="outline">{dark ? "Light" : "Dark"} mode</Button>
                <Button as="a" href="/contact" className="flex-1">Talk to us</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}