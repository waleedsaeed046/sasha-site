import { ReactNode } from "react";

export function Section({ id, eyebrow, title, subtitle, children }:{ id?: string, eyebrow?: string, title?: string, subtitle?: string, children: ReactNode }) {
  return (
    <section id={id} className="relative py-20 sm:py-24">
      <div className="absolute inset-0 pointer-events-none [mask-image:radial-gradient(60%_60%_at_50%_20%,black,transparent)] bg-gradient-to-b from-indigo-50 to-transparent dark:from-indigo-900/10"/>
      <div className="relative container">
        <div className="max-w-3xl">
          {eyebrow && <div className="text-xs tracking-widest uppercase text-indigo-600 dark:text-indigo-400 font-semibold">{eyebrow}</div>}
          {title && <h2 className="text-3xl/tight sm:text-4xl font-bold mt-2">{title}</h2>}
          {subtitle && <p className="text-neutral-600 dark:text-neutral-300 mt-3 text-lg">{subtitle}</p>}
        </div>
        <div className="mt-10">{children}</div>
      </div>
    </section>
  );
}