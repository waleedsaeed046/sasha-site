import Link from "next/link";
import Image from "next/image";
import { site } from "@/lib/site";

export function Footer() {
  return (
    <footer className="border-t border-neutral-200 dark:border-neutral-800 py-10 mt-16">
      <div className="container">
        <div className="grid md:grid-cols-3 gap-8 items-start">
          <div>
            <div className="flex items-center gap-2">
              <Image src="/logo.png" alt="Sasha Nexus" width={32} height={32} className="rounded-md" />
              <span className="font-semibold">Sasha Nexus</span>
            </div>
            <p className="mt-3 text-sm text-neutral-600 dark:text-neutral-300 max-w-sm">
              We design, build, and scale secure digital products with modern cloud, data, and AI.
            </p>
            <div className="mt-4 flex items-center gap-3 text-sm text-neutral-500 dark:text-neutral-400">
              <a href={site.linkedin}>LinkedIn</a>
              <a href={site.x}>X</a>
              <a href={site.github}>GitHub</a>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div>
              <div className="text-sm font-semibold mb-3">Company</div>
              <ul className="space-y-2 text-sm text-neutral-600 dark:text-neutral-300">
                <li><Link href="/about">About</Link></li>
                <li><Link href="/careers">Careers</Link></li>
                <li><Link href="/work">Case studies</Link></li>
                <li><Link href="/services">Services</Link></li>
              </ul>
            </div>
            <div>
              <div className="text-sm font-semibold mb-3">Legal</div>
              <ul className="space-y-2 text-sm text-neutral-600 dark:text-neutral-300">
                <li><Link href="/privacy">Privacy</Link></li>
                <li><Link href="/terms">Terms</Link></li>
                <li><Link href="/cookies">Cookies</Link></li>
              </ul>
            </div>
          </div>

          <div className="md:text-right text-sm text-neutral-500">
            <div>© {new Date().getFullYear()} Sasha Nexus. All rights reserved.</div>
            <div className="mt-2 text-xs">Made with ♥ in London.</div>
          </div>
        </div>
      </div>
    </footer>
  );
}