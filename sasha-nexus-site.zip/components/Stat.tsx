import { CheckCircle2 } from "lucide-react";

export function Stat({ k, v }:{ k: string, v: string }) {
  return (
    <div className="flex items-center gap-3">
      <CheckCircle2 className="w-5 h-5 text-indigo-500" />
      <div>
        <div className="text-sm text-neutral-500 dark:text-neutral-400">{k}</div>
        <div className="text-xl font-semibold">{v}</div>
      </div>
    </div>
  );
}